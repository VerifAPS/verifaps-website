#!/bin/sh

dist/bin/rvt                          \
    -L library.st                     \
    --old Crane12.st --old-name Crane \
    --new Crane13.st --new-name Crane \
    --miter UNTIL --until-miter-cond inputconstraint.smv \
    --do-not-verify
