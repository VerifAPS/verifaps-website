#!/bin/sh

dist/bin/rvt                          \
    -L library.st                     \
    --old Crane12.st --old-name Crane \
    --new Crane13.st --new-name Crane \
    --miter UNTIL --until-miter-cond inputconstraint.smv \
    --do-not-verify

/usr/bin/time \
    /home/weigl/share/nuXmv-1.1.1-Linux/bin/nuXmv -source commands.xmv \
    main.stable.smv
