#!/bin/sh

/usr/bin/time \
    /home/weigl/share/nuXmv-1.1.1-Linux/bin/nuXmv -source commands.xmv main.stable.smv
